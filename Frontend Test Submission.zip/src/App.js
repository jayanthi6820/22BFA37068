import React, { useState, useEffect } from "react";
import {
  Container,
  TextField,
  Button,
  Typography,
  Box,
  Card,
  CardContent,
} from "@mui/material";
import {
  Routes,
  Route,
  useParams,
  useNavigate,
} from "react-router-dom";

const RedirectHandler = () => {
  const { code } = useParams();
  const navigate = useNavigate();

  useEffect(() => {
    const handleRedirect = async () => {
      try {
        const res = await fetch(`http://localhost:5000/${code}`);
        const data = await res.json();
        if (data.originalUrl) {
          window.location.href = data.originalUrl;
        } else {
          navigate("/");
        }
      } catch (err) {
        console.error("Redirect failed", err);
        navigate("/");
      }
    };
    handleRedirect();
  }, [code, navigate]);

  return <h3>Redirecting...</h3>;
};

const Home = () => {
  const [url, setUrl] = useState("");
  const [validity, setValidity] = useState("");
  const [shortcode, setShortcode] = useState("");
  const [shortened, setShortened] = useState(null);
  const [error, setError] = useState("");

  const handleShorten = async () => {
    try {
      const res = await fetch("http://localhost:5000/api/shorten", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          originalUrl: url,
          validity: validity || 30,
          shortcode,
        }),
      });
      const data = await res.json();
      setShortened(data);
      setError("");
    } catch (err) {
      setError("Failed to shorten URL");
    }
  };

  return (
    <Container maxWidth="sm" sx={{ mt: 5, fontFamily: "monospace" }}>
      <Typography variant="h4" gutterBottom>
        URL Shortener
      </Typography>
      <TextField
        fullWidth
        label="Original URL"
        value={url}
        onChange={(e) => setUrl(e.target.value)}
        sx={{ mb: 2 }}
      />
      <TextField
        fullWidth
        label="Validity (minutes)"
        value={validity}
        onChange={(e) => setValidity(e.target.value)}
        sx={{ mb: 2 }}
      />
      <TextField
        fullWidth
        label="Preferred Shortcode (optional)"
        value={shortcode}
        onChange={(e) => setShortcode(e.target.value)}
        sx={{ mb: 2 }}
      />
      <Button variant="contained" onClick={handleShorten}>
        SHORTEN
      </Button>
      {error && (
        <Typography color="error" sx={{ mt: 2 }}>
          {error}
        </Typography>
      )}
      {shortened && (
        <Card sx={{ mt: 4 }}>
          <CardContent>
            <Typography>
              <strong>Original:</strong> {shortened.originalUrl}
            </Typography>
            <Typography>
              <strong>Shortened:</strong>{" "}
              <a href={`/${shortened.shortcode}`}>{`/${shortened.shortcode}`}</a>
            </Typography>
            <Typography>
              <strong>Expires At:</strong> {shortened.expiresAt}
            </Typography>
            <Typography>
              <strong>Clicks:</strong> {shortened.clicks?.length || 0}
            </Typography>
            {shortened.clicks &&
              shortened.clicks.map((click, index) => (
                <Box key={index} sx={{ mt: 1 }}>
                  <Typography>
                    Clicked at: {click.timestamp}
                    <br />
                    Source: {click.source}, Location: {click.location}
                  </Typography>
                </Box>
              ))}
          </CardContent>
        </Card>
      )}
    </Container>
  );
};

const App = () => {
  return (
    <Routes>
      <Route path="/" element={<Home />} />
      <Route path="/:code" element={<RedirectHandler />} />
    </Routes>
  );
};

export default App;
